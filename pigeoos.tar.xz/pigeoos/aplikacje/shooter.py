import pygame
import random
import sys

# Inicjalizacja
pygame.init()
screen = pygame.display.set_mode((800, 600))
clock = pygame.time.Clock()

# --- ZMIENNE ---
player_pos = [400, 500]
bullets = []
enemies = []

# --- LOGIKA WROGÓW ---
def spawn_enemy():
    x = random.randint(0, 750)
    enemies.append([x, 0])

# Główna pętla gry
running = True
spawn_timer = 0

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT: running = False
        if event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
            bullets.append([player_pos[0] + 20, player_pos[1]])

    # Sterowanie
    keys = pygame.key.get_pressed()
    if keys[pygame.K_a] and player_pos[0] > 0: player_pos[0] -= 7
    if keys[pygame.K_d] and player_pos[0] < 750: player_pos[0] += 7

    # Spawnowanie wrogów co 60 klatek
    spawn_timer += 1
    if spawn_timer > 60:
        spawn_enemy()
        spawn_timer = 0

    # Ruch wrogów i pocisków
    for b in bullets[:]:
        b[1] -= 10
        if b[1] < 0: bullets.remove(b)

    for e in enemies[:]:
        e[1] += 3
        if e[1] > 600: enemies.remove(e) # Wróg uciekł

    # Wykrywanie kolizji (Strzelanie)
    for b in bullets[:]:
        for e in enemies[:]:
            # Tworzymy prostokąty dla łatwego sprawdzania kolizji
            rect_bullet = pygame.Rect(b[0], b[1], 10, 10)
            rect_enemy = pygame.Rect(e[0], e[1], 50, 50)
            
            if rect_bullet.colliderect(rect_enemy):
                if b in bullets: bullets.remove(b)
                if e in enemies: enemies.remove(e)

    # Rysowanie
    screen.fill((30, 30, 30))
    pygame.draw.rect(screen, (0, 255, 0), (player_pos[0], player_pos[1], 50, 50)) # Gracz
    for e in enemies: pygame.draw.rect(screen, (255, 255, 0), (e[0], e[1], 50, 50)) # Wróg
    for b in bullets: pygame.draw.circle(screen, (255, 0, 0), (b[0], b[1]), 5) # Pocisk

    pygame.display.flip()
    clock.tick(60)

pygame.quit()
sys.exit()