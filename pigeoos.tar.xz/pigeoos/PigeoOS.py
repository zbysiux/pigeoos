# =========================================================
# PIGEOOS ULTIMATE EDITION FULL
# =========================================================

import tkinter as tk
from tkinter import filedialog, messagebox
import os
import sys
import time
import platform
import subprocess
import webbrowser
import random
import json

# =========================================================
# OPTIONAL MODULES
# =========================================================

try:
    import psutil
except:
    psutil = None

try:
    from PIL import ImageGrab
except:
    ImageGrab = None

# =========================================================
# USER FILE
# =========================================================

USER_FILE = "user.json"

def save_user(username, password):

    data = {
        "username": username,
        "password": password
    }

    with open(USER_FILE, "w") as f:
        json.dump(data, f)

def load_user():

    if os.path.exists(USER_FILE):

        with open(USER_FILE, "r") as f:
            return json.load(f)

    return None

# =========================================================
# LOGIN
# =========================================================

class LoginWindow(tk.Tk):

    def __init__(self):

        super().__init__()

        self.title("PigeoOS Login")
        self.geometry("500x350")
        self.configure(bg="#1f1f1f")

        title = tk.Label(
            self,
            text="PigeoOS",
            font=("Segoe UI", 30, "bold"),
            bg="#1f1f1f",
            fg="white"
        )

        title.pack(pady=30)

        self.user_entry = tk.Entry(
            self,
            font=("Segoe UI", 14)
        )

        self.user_entry.pack(pady=10)

        self.pass_entry = tk.Entry(
            self,
            show="*",
            font=("Segoe UI", 14)
        )

        self.pass_entry.pack(pady=10)

        if load_user() is None:

            btn = tk.Button(
                self,
                text="Create Account",
                command=self.create_account,
                bg="#2d89ef",
                fg="white",
                relief="flat",
                width=20
            )

        else:

            btn = tk.Button(
                self,
                text="Login",
                command=self.login,
                bg="#2d89ef",
                fg="white",
                relief="flat",
                width=20
            )

        btn.pack(pady=20)

    def create_account(self):

        username = self.user_entry.get()
        password = self.pass_entry.get()

        if username and password:

            save_user(username, password)

            self.destroy()

            app = PigeoOS()
            app.mainloop()

    def login(self):

        user = load_user()

        if (
            self.user_entry.get() == user["username"]
            and
            self.pass_entry.get() == user["password"]
        ):

            self.destroy()

            app = PigeoOS()
            app.mainloop()

        else:

            messagebox.showerror(
                "Error",
                "Wrong password"
            )

# =========================================================
# WINDOW
# =========================================================

class AppWindow(tk.Toplevel):

    def __init__(self, master, title, w, h):

        super().__init__(master)

        self.title(title)
        self.geometry(f"{w}x{h}")
        self.configure(bg="#1f1f1f")

        self.content = tk.Frame(
            self,
            bg="#1f1f1f"
        )

        self.content.pack(fill="both", expand=True)

# =========================================================
# MAIN SYSTEM
# =========================================================

class PigeoOS(tk.Tk):

    def __init__(self):

        super().__init__()

        self.title("PigeoOS")
        self.geometry("1280x720")
        self.configure(bg="#202020")

        self.wallpaper = "#202020"

        self.create_desktop()
        self.create_taskbar()
        self.create_start_menu()

    # =====================================================
    # DESKTOP
    # =====================================================

    def create_desktop(self):

        self.desktop = tk.Frame(
            self,
            bg=self.wallpaper
        )

        self.desktop.pack(fill="both", expand=True)

        title = tk.Label(
            self.desktop,
            text="PigeoOS",
            font=("Segoe UI", 30, "bold"),
            bg=self.wallpaper,
            fg="white"
        )

        title.place(x=30, y=20)

        apps = [

            ("📄\nNotes", self.open_notes),
            ("🖌️\nPaint", self.open_paint),
            ("🧮\nCalculator", self.open_calculator),
            ("🌐\nBrowser", self.open_browser),
            ("💻\nTerminal", self.open_terminal),
            ("⚙️\nSettings", self.open_settings),
            ("🎮\nShooter.py", self.open_external_shooter),
            ("ℹ️\nSystem", self.open_system_info),
            ("🎲\nMiniGame", self.open_minigame)

        ]

        for i, (name, cmd) in enumerate(apps):

            btn = tk.Button(
                self.desktop,
                text=name,
                command=cmd,
                width=12,
                height=4,
                bg="#303030",
                fg="white",
                relief="flat",
                font=("Segoe UI", 10)
            )

            btn.place(
                x=40,
                y=120 + i * 85
            )

    # =====================================================
    # TASKBAR
    # =====================================================

    def create_taskbar(self):

        self.taskbar = tk.Frame(
            self,
            bg="#101010",
            height=40
        )

        self.taskbar.pack(side="bottom", fill="x")

        start = tk.Button(
            self.taskbar,
            text="Start",
            command=self.toggle_start_menu,
            bg="#2d89ef",
            fg="white",
            relief="flat"
        )

        start.pack(side="left", padx=5, pady=5)

        self.clock = tk.Label(
            self.taskbar,
            bg="#101010",
            fg="white",
            font=("Segoe UI", 10)
        )

        self.clock.pack(side="right", padx=10)

        self.update_clock()

    # =====================================================
    # START MENU
    # =====================================================

    def create_start_menu(self):

        self.start_visible = False

        self.start_menu = tk.Frame(
            self,
            bg="#2a2a2a",
            width=260,
            height=500
        )

        buttons = [

            ("Applications", self.show_apps),
            ("Settings", self.open_settings),
            ("Restart System", self.restart_system),
            ("Shutdown System", self.shutdown_system)

        ]

        for text, cmd in buttons:

            btn = tk.Button(
                self.start_menu,
                text=text,
                command=cmd,
                bg="#333333",
                fg="white",
                relief="flat",
                anchor="w",
                padx=10
            )

            btn.pack(fill="x", padx=10, pady=5)

    def toggle_start_menu(self):

        if self.start_visible:

            self.start_menu.place_forget()
            self.start_visible = False

        else:

            self.start_menu.place(
                x=0,
                y=220
            )

            self.start_visible = True

    # =====================================================
    # CLOCK
    # =====================================================

    def update_clock(self):

        self.clock.config(
            text=time.strftime("%H:%M:%S")
        )

        self.after(1000, self.update_clock)

    # =====================================================
    # APPLICATIONS WINDOW
    # =====================================================

    def show_apps(self):

        window = AppWindow(
            self,
            "Applications",
            400,
            550
        )

        title = tk.Label(
            window.content,
            text="Installed Applications",
            font=("Segoe UI", 20, "bold"),
            bg="#1f1f1f",
            fg="white"
        )

        title.pack(pady=15)

        apps = [

            ("📄 Notes", self.open_notes),
            ("🖌️ Paint", self.open_paint),
            ("🧮 Calculator", self.open_calculator),
            ("🌐 Browser", self.open_browser),
            ("💻 Terminal", self.open_terminal),
            ("⚙️ Settings", self.open_settings),
            ("🎮 Shooter.py", self.open_external_shooter),
            ("ℹ️ System Info", self.open_system_info),
            ("🎲 Mini Game", self.open_minigame)

        ]

        for name, cmd in apps:

            btn = tk.Button(
                window.content,
                text=name,
                command=cmd,
                font=("Segoe UI", 12),
                bg="#2d2d2d",
                fg="white",
                relief="flat",
                anchor="w",
                padx=10,
                pady=10
            )

            btn.pack(
                fill="x",
                padx=20,
                pady=5
            )

    # =====================================================
    # NOTES
    # =====================================================

    def open_notes(self):

        window = AppWindow(
            self,
            "Notes",
            700,
            500
        )

        toolbar = tk.Frame(
            window.content,
            bg="#2a2a2a"
        )

        toolbar.pack(fill="x")

        text = tk.Text(
            window.content,
            bg="#111111",
            fg="white",
            insertbackground="white"
        )

        text.pack(fill="both", expand=True)

        def save_note():

            file = filedialog.asksaveasfilename(
                defaultextension=".txt"
            )

            if file:

                with open(file, "w", encoding="utf-8") as f:

                    f.write(
                        text.get("1.0", "end")
                    )

        save_btn = tk.Button(
            toolbar,
            text="Save",
            command=save_note
        )

        save_btn.pack(side="left", padx=5, pady=5)

    # =====================================================
    # PAINT
    # =====================================================

    def open_paint(self):

        window = AppWindow(
            self,
            "Paint",
            900,
            600
        )

        toolbar = tk.Frame(
            window.content,
            bg="#2a2a2a"
        )

        toolbar.pack(fill="x")

        canvas = tk.Canvas(
            window.content,
            bg="white"
        )

        canvas.pack(fill="both", expand=True)

        color = "black"

        def draw(event):

            x, y = event.x, event.y

            canvas.create_oval(
                x,
                y,
                x + 4,
                y + 4,
                fill=color,
                outline=color
            )

        canvas.bind("<B1-Motion>", draw)

        def save_paint():

            if ImageGrab is None:

                messagebox.showerror(
                    "Error",
                    "Install pillow"
                )

                return

            file = filedialog.asksaveasfilename(
                defaultextension=".png"
            )

            if file:

                x = canvas.winfo_rootx()
                y = canvas.winfo_rooty()

                x1 = x + canvas.winfo_width()
                y1 = y + canvas.winfo_height()

                ImageGrab.grab().crop(
                    (x, y, x1, y1)
                ).save(file)

        save_btn = tk.Button(
            toolbar,
            text="Save"
        )

        save_btn.pack(side="left", padx=5)

        save_btn.config(command=save_paint)

    # =====================================================
    # CALCULATOR
    # =====================================================

    def open_calculator(self):

        window = AppWindow(
            self,
            "Calculator",
            320,
            450
        )

        expr = tk.StringVar()

        entry = tk.Entry(
            window.content,
            textvariable=expr,
            font=("Segoe UI", 24),
            justify="right"
        )

        entry.pack(fill="x", padx=10, pady=10)

        buttons = [

            ['7','8','9','/'],
            ['4','5','6','*'],
            ['1','2','3','-'],
            ['0','.','=','+']

        ]

        def click(v):

            if v == "=":

                try:
                    expr.set(
                        str(eval(expr.get()))
                    )
                except:
                    expr.set("Error")

            else:

                expr.set(
                    expr.get() + v
                )

        for row in buttons:

            frame = tk.Frame(window.content)

            frame.pack(expand=True, fill="both")

            for char in row:

                btn = tk.Button(
                    frame,
                    text=char,
                    font=("Segoe UI", 18),
                    command=lambda c=char: click(c)
                )

                btn.pack(
                    side="left",
                    expand=True,
                    fill="both"
                )

    # =====================================================
    # BROWSER
    # =====================================================

    def open_browser(self):

        window = AppWindow(
            self,
            "Browser",
            500,
            200
        )

        entry = tk.Entry(
            window.content,
            font=("Segoe UI", 14)
        )

        entry.pack(fill="x", padx=20, pady=20)

        entry.insert(0, "https://google.com")

        def open_url():

            url = entry.get()

            if not url.startswith("http"):
                url = "https://" + url

            webbrowser.open(url)

        btn = tk.Button(
            window.content,
            text="Open",
            command=open_url
        )

        btn.pack()

    # =====================================================
    # TERMINAL
    # =====================================================

    def open_terminal(self):

        window = AppWindow(
            self,
            "Terminal",
            900,
            600
        )

        text = tk.Text(
            window.content,
            bg="black",
            fg="#00ff00",
            insertbackground="white",
            font=("Consolas", 11)
        )

        text.pack(fill="both", expand=True)

        prompt = "pigeo@os:~$ "

        text.insert(
            "end",
            "PigeoOS Terminal v3\n"
            "Type HELP\n\n"
        )

        text.insert("end", prompt)

        def enter(event):

            line = text.get(
                "insert linestart",
                "insert lineend"
            )

            cmd = line.replace(prompt, "").strip()

            text.insert("end", "\n")

            c = cmd.lower()

            if c == "help":

                text.insert(
                    "end",
                    """
help
clear
time
date
system
ram
cpu
battery
storage
hack
pigeoos
"""
                )

            elif c == "clear":

                text.delete("1.0", "end")

            elif c == "time":

                text.insert(
                    "end",
                    time.strftime("%H:%M:%S\n")
                )

            elif c == "date":

                text.insert(
                    "end",
                    time.strftime("%d-%m-%Y\n")
                )

            elif c == "system":

                text.insert(
                    "end",
                    f"""
System: PigeoOS
Python: {platform.python_version()}
CPU: {platform.processor()}
"""
                )

            elif c == "ram":

                if psutil:

                    text.insert(
                        "end",
                        f"RAM: {psutil.virtual_memory().percent}%\n"
                    )

            elif c == "cpu":

                if psutil:

                    text.insert(
                        "end",
                        f"CPU: {psutil.cpu_percent()}%\n"
                    )

            elif c == "battery":

                if psutil:

                    battery = psutil.sensors_battery()

                    if battery:

                        text.insert(
                            "end",
                            f"Battery: {battery.percent}%\n"
                        )

            elif c == "storage":

                if psutil:

                    disk = psutil.disk_usage("/")

                    text.insert(
                        "end",
                        f"Disk: {disk.percent}%\n"
                    )

            elif c == "hack":

                for i in range(0, 101, 5):

                    text.insert(
                        "end",
                        f"HACKING NASA {i}%\n"
                    )

                    text.update()
                    time.sleep(0.03)

                text.insert(
                    "end",
                    "ACCESS GRANTED 😎\n"
                )

            elif c == "pigeoos":

                pigeon = r"""

⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⣶⣶⣶⣦⡀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⣾██████⣷
⠀⠀⠀⠀⠀⠀⠀⠀⣼████████⣧
⠀⠀⠀⠀⠀⠀⠀⠀████▀▀▀▀████
⠀⠀⠀⠀⠀⠀⠀⠀████⠀⠀⠀████
⠀⠀⠀⠀⠀⠀⠀⠀████▄▄▄▄▄████
⠀⠀⠀⠀⠀⠀⠀⠀▀██████████▀
⠀⠀⠀⠀⠀⠀⠀⠀⠀▀██████▀

"""

                text.insert(
                    "end",
                    pigeon
                )

                text.insert(
                    "end",
                    "\nPIGEO MODE ACTIVATED\n"
                )

            else:

                text.insert(
                    "end",
                    f"Unknown command: {cmd}\n"
                )

            text.insert(
                "end",
                "\n" + prompt
            )

            text.see("end")

            return "break"

        text.bind("<Return>", enter)

    # =====================================================
    # SETTINGS
    # =====================================================

    def open_settings(self):

        window = AppWindow(
            self,
            "Settings",
            400,
            300
        )

        label = tk.Label(
            window.content,
            text="Wallpaper Color",
            bg="#1f1f1f",
            fg="white"
        )

        label.pack(pady=10)

        colors = [

            "#202020",
            "#003366",
            "#330033",
            "#003300",
            "#550000"

        ]

        def set_wallpaper(c):

            self.wallpaper = c

            self.desktop.config(
                bg=c
            )

        for c in colors:

            btn = tk.Button(
                window.content,
                bg=c,
                width=20,
                command=lambda color=c:
                set_wallpaper(color)
            )

            btn.pack(pady=5)

    # =====================================================
    # SYSTEM INFO
    # =====================================================

    def open_system_info(self):

        window = AppWindow(
            self,
            "System Info",
            500,
            350
        )

        info = f"""
System: PigeoOS

Python:
{platform.python_version()}

CPU:
{platform.processor()}

Architecture:
{platform.machine()}

Computer:
{platform.node()}
"""

        label = tk.Label(
            window.content,
            text=info,
            justify="left",
            bg="#1f1f1f",
            fg="white",
            font=("Consolas", 12)
        )

        label.pack(padx=20, pady=20)

    # =====================================================
    # SHOOTER
    # =====================================================

    def open_external_shooter(self):

        os.makedirs(
            "aplikacje",
            exist_ok=True
        )

        shooter = os.path.join(
            "aplikacje",
            "shooter.py"
        )

        if os.path.exists(shooter):

            subprocess.Popen(
                [sys.executable, shooter]
            )

        else:

            messagebox.showerror(
                "Error",
                "Put shooter.py into aplikacje folder"
            )

    # =====================================================
    # MINI GAME
    # =====================================================

    def open_minigame(self):

        window = AppWindow(
            self,
            "MiniGame",
            400,
            300
        )

        score = tk.IntVar(value=0)

        label = tk.Label(
            window.content,
            text="Catch Button",
            font=("Segoe UI", 20),
            bg="#1f1f1f",
            fg="white"
        )

        label.pack()

        score_label = tk.Label(
            window.content,
            textvariable=score,
            font=("Segoe UI", 16),
            bg="#1f1f1f",
            fg="cyan"
        )

        score_label.pack()

        btn = tk.Button(
            window.content,
            text="CLICK"
        )

        btn.place(x=100, y=100)

        def move():

            score.set(
                score.get() + 1
            )

            btn.place(
                x=random.randint(0, 300),
                y=random.randint(0, 200)
            )

        btn.config(command=move)

    # =====================================================
    # RESTART
    # =====================================================

    def restart_system(self):

        python = sys.executable

        os.execl(
            python,
            python,
            *sys.argv
        )

    # =====================================================
    # SHUTDOWN
    # =====================================================

    def shutdown_system(self):

        self.destroy()

# =========================================================
# START
# =========================================================

if __name__ == "__main__":

    login = LoginWindow()
    login.mainloop()